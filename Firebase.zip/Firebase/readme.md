1. Nhiều Pages: home, login-signup, sản phẩm, about, feedback, blogs, settings
2. Có đăng nhập đăng ký (Lưu thông tin online)
3. Lưu thông tin sản phẩm (tên, mô tả, giá, ...); Lưu hình ảnh sản phẩm online

4. Cấu trúc dự án
5. Config
6. Login, register = firebase autithencation
