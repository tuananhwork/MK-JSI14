import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.9.0/firebase-app.js';

const firebaseConfig = {
  apiKey: 'AIzaSyBcVh_FEb21fefLAzME-Mr3n3hcp44RPO0',
  authDomain: 'fir-jsi14.firebaseapp.com',
  projectId: 'fir-jsi14',
  storageBucket: 'fir-jsi14.appspot.com',
  messagingSenderId: '1013941185345',
  appId: '1:1013941185345:web:f3972e4ed46017df86cfc0',
};

export const app = initializeApp(firebaseConfig);
