import { app } from './firebase-config.js';
import { getStorage } from 'https://www.gstatic.com/firebasejs/10.9.0/firebase-storage.js';

const storage = getStorage(app);

console.log(storage);

const uploadForm = document.getElementById('upload-form');
const productImage = document.getElementById('product-image');
const productImageShow = document.getElementById('product-image-show');
const productName = document.getElementById('product-name');
const productPrice = document.getElementById('product-price');
const productDesc = document.getElementById('product-description');
const uploadBtn = document.getElementById('upload-btn');

const init = () => {
  setTimeout(() => {
    productImageShow.style.display = 'none';
    productName.value = '';
    productPrice.value = '';
    productDesc.value = '';
    uploadBtn.textContent = 'Upload';
  }, 1000);
};

// Change image when upload file done
productImage.onchange = (event) => {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function (e) {
      productImageShow.src = e.target.result;
      productImageShow.style.display = 'block';
    };
    reader.readAsDataURL(file);
  }
};
